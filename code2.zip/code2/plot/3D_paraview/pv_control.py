typeList = ['slice', 'contour']

case = 'case1_ref'
cycles = [30000, 30200]
# cycles = [23200, 23400]
# cycles = [25000, 25200]
# cycles = [28200, 28400]

pvtype = typeList[0]

# output = 'composition_2'
output = 'melt_fraction'
# output = 'temperature'
pvrange = [0, 0.04]
# pvrange = [1000 / 2104, 2200 / 2104]

normal = [0, 1, 0]
show = True
save = False
gif = False
glyph = False
arrowScale = 8e-2
